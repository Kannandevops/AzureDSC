New-Item -Path �HKLM:\Software\AppX�

Mkdir C:\AppX